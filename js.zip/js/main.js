document.addEventListener("deviceready", function(){
	console.log('device ready');
	setupPush()
	setup();
	//add event listeners

});

//browser testing
$(document).ready(function() {
	console.log('ready');
	setup();

});

//setup
function setup() {
	if (window.navigator.offLine){
		$("#search").text('No intenet access')
			.attr("data-icon", "delete")
			.button('refresh');
		}else{
			console.log('online');
		}
	}


