//browser testing
$(document).ready(function() {
	console.log('device ready');
	setup();

});

//test internet connection
function setup() {
	if (window.navigator.offLine){
		$("#searchonline").text('No intenet access')
		}else{
			console.log('online');
		}
	}


const songName = document.querySelector('.songTitle');
    const songLyrics = document.querySelector('.lyricResults');

function findLyrics() {
	//get the artst and song name entered by user
	const artist = document.getElementById('artistName').value;
    const song = document.getElementById('songTitle').value;

    //vars to hold lyrics/title
   
    const error = document.querySelector('.error');

    //call API
    const songRequest = `https://api.lyrics.ovh/v1/${artist}/${song}`;

    fetch(songRequest)
        .then(function(response) {
            return response.json();
        })
        .then(function(response) {
        	songName.innerText = artist + " - " + song;
            console.log(songName);
            console.log(response.lyrics);
            songLyrics.innerText = response.lyrics ? response.lyrics : "Sorry. We can't find that song :(";
        })
        .catch(function(response) {
            error.innerText = "Error: Not connected to the internet"
        })

       return songName;
    }




const form = document.querySelector('.log');

form.addEventListener('submit', function(e) {
    e.preventDefault();
    findLyrics();
})






//favlist
	// Get form, item, and songlist
	var addTosonglist = document.querySelector('#add-to-songlist');
	var songlistItem = document.querySelector('#songTitle');
	var songlist = document.querySelector('#songlist');

	addTosonglist.addEventListener('submit', function (event) {

		// Don't submit the form
		event.preventDefault();

		// Ignore it if the songlist item is empty
		if (songlistItem.value.length < 1) return;

		// Add item to songlist
		songlist.innerHTML += '<li>' + songlistItem.value + '</li>';

		// Clear input
		songlistItem.value = '';

		// Save the list to localStorage
		localStorage.setItem('songlistItems', songlist.innerHTML);

	}, false);

	// Check for saved songlist items
	var saved = localStorage.getItem('songlistItems');

	// If there are any saved items, update our list
	if (saved) {
		songlist.innerHTML = saved;
	}
	




/*$('#favBtn').click(function(){
    addFav();
});

function addFav(){
    if(localStorage.getItem('favourites')){//If there are favourites
        var storage = JSON.parse(localStorage['favourites']);
			if (storage.indexOf(songName.id) == -1) { 
				  //not found
				  storage.push(songName.id);
				  localStorage.setItem('favourites', JSON.stringify(storage));
				} else {
				//found
				  console.log('item already in favorites')
				 
				}
	 }else{//No favourites in local storage, so add new
        var favArray= [];
        favArray.push(songName.text);
        localStorage.setItem("favourites", JSON.stringify(favArray));
        console.log('New favourites list');
		
		}
	
}*/

		
	
		
// capture callback
var captureSuccess = function(mediaFiles) {
    var i, path, len;
    for (i = 0, len = mediaFiles.length; i < len; i += 1) {
        path = mediaFiles[i].fullPath;
        // do something interesting with the file
    }
};

// capture error callback
var captureError = function(error) {
    navigator.notification.alert('Error code: ' + error.code, null, 'Capture Error');
};

// start audio capture
navigator.device.capture.captureAudio(captureSuccess, captureError, {limit:2});






// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}

